﻿using UnityEngine;
using System.Collections;

public class MonkeyController : MonoBehaviour
{

    public Rigidbody2D myRigitBody;
    //public Animator myRigitBodyAnimation;
    public float jumpForce = 60f;
    public float horizontalMove = 1f;
    bool jumped = false;

    //float distToGround = 0;

    // Use this for initialization
    void Start()
    {
        myRigitBody = GetComponent<Rigidbody2D>();
        //myRigitBodyAnimation = GetComponent<Animator>();
    }

    public bool IsGrounded()
    {
        if (myRigitBody.velocity.y == 0f) { return true; }
        else return false;
    }


// Update is called once per frame
void Update()
    {

       // if (jumped == true) { myRigitBodyAnimation = jump; }

        if (Input.GetKey("z") && jumped == false)
        {
            myRigitBody.AddForce(transform.up * jumpForce);
            
            jumped = true;
        }

        
      
        if (IsGrounded() == true){
            jumped = false;
            }
         
       myRigitBody.transform.Translate(Vector3.right * horizontalMove * Time.deltaTime);



    }

    void FixedUpdated()
    {
        



    }


}
